﻿namespace GovElec.App.Extensions;

public static class TokenExtension
{

}
