


namespace GovElec.Api.Features.Users;

public class UpdateUserEndpoint : IEndpoint
{
    public void MapEndpoint(IEndpointRouteBuilder app)
    {
        app.MapPut("/api/users/update/{id:guid}", async (Guid id, UserForUpdateCommand command, AppDbContext dbContext) =>
        {
            var user = await dbContext.Users.FindAsync(id);
            if (user == null)
            {
                return Results.NotFound("Utilisateur non trouvé.");
            }

            // Update user details : Ne pas utiliser Mapster car si le Password est vide, mapster va écraser le mot de passe existant
            user.UserName = command.UserName;
            user.FullName = command.FullName;
            user.Equipe = command.Equipe;
            user.Email = command.Email;
            user.Phone = command.Phone;
            user.Role = UserRole.User;
            user.IsDeleted = command.IsDeleted;
            if (!string.IsNullOrEmpty(command.OldPassword))
            {
                var changePassword = !string.IsNullOrEmpty(command.Password) &&
                !string.IsNullOrEmpty(command.ConfirmPassword) &&
                command.Password != command.ConfirmPassword
                && BCrypt.Net.BCrypt.Verify(command.OldPassword, user.PasswordHash);
                if (changePassword)
                {
                    if (command.Password != command.ConfirmPassword)
                    {
                        return Results.BadRequest("Le mot de passe et la confirmation du mot de passe ne correspondent pas.");
                    }
                    user.PasswordSalt = BCrypt.Net.BCrypt.GenerateSalt();
                    user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(command.Password, user.PasswordSalt);
                }
            }
            dbContext.Update(user);
            await dbContext.SaveChangesAsync();
            var response= user.Adapt<UserForReadResponse>();
            return Results.Ok(response);
        }).WithTags("Users")
          .Produces<User>(StatusCodes.Status200OK)
          .Produces(StatusCodes.Status404NotFound)
          .WithName("UpdateUser")
          .WithSummary("Met à jour les détails d'un utilisateur existant.")
          .WithDescription("This endpoint allows you to update the details of an existing user by providing the user's ID and the new details.");
    }
}
