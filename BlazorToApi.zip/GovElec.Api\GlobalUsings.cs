global using GovElec.Api.Abstractions;
global using GovElec.Api.Models;
global using GovElec.Api.Services;
global using GovElec.Api.Data;
global using GovElec.Shared;

global using Microsoft.EntityFrameworkCore;

global using Mapster;